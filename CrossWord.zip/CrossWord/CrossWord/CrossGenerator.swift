//
//  CrossGenerator.swift
//  CrossWord
//
//  Created by Gary Chan on 3/20/19.
//  Copyright © 2019 Rickster Software. All rights reserved.
//

import Foundation

let generator = CrosswordsGenerator(columns: 10, rows: 10, maxLoops: 2000, words: ["saffron", "pumpernicke","leaven","cola", "])

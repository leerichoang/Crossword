// Written By Eric Le

import Foundation
import UIKit


print("Create an instance of an immutable String, and an instance of a mutable String, print them out, and show why one String is mutable and the other is not")
// Question 1:
var muteStr : String = "one"
print(muteStr)
muteStr = "two"
print(muteStr)



print("Using a for loop, print out all of the characters in the following String one by one: 'you get out of life what you put into it'")

// Question 2:

let abc : String = "you get out of life what you put into it"
for char in abc{
    print(char)
}


print("Write a function in Swift called \nprint_nth_char(_ forString: String, withIndex: Int)\nfor printing out the nth character in a String.\nHint: You will need an Index to do that.\nget the start index;  Get the index offset from the start; access the character, and print it out")



func print_nth_char(forString: String, withIndex: Int){
    print(forString[forString.index(forString.startIndex, offsetBy: withIndex-1)])

}
print_nth_char(forString: "00000100", withIndex: 6)

print("Write a function in Swift called strlen(_ forString: String), for finding the length \nof the String: 'The Good, the Bad, and the Ugly.'")

func strlen(_ forString: String){
    print(String(forString).count)

}

strlen("The Good, the Bad, and the Ugly.")


print("Print out the unicode values (base 10) of the above String 'This above all: to thine own self be true..'")

let str : String = "This above all: to thine own self be true.."
for index in str.indices {
    print(String(format:"%02d", str[index].unicodeScalars.first!.value), terminator: " ")
}
print("\n\n")




print("Print out the unicode values (base 16) of the above String 'This above all: to thine own self be true.'")

let newstr : String = "This above all: to thine own self be true."
for char in newstr.utf16 {
    print(char)
}




print("Write out the formula for reversing the String 'Give thy thoughts no tongue.'")
let reverse : String = "Give thy thoughts no tongue."
print(String(reverse.reversed()))



print("Given that “middle” in Chinese is “zhong1”: unicode 4e2d, and “kingdom” is: “guo2”: 570d,")

print("\u{4e2d}\u{570d}")



print("Convert the following String to all lowercase: 'Some are born great, Some achieve greatness, and Some have greatness thrust upon them'.")

print("Some are born great, Some achieve greatness, and Some have greatness thrust upon them".lowercased())



print("Change all of the consonants in the String: 'neither a borrow nor a lender be' to be 'A'.")
print("neither a borrow nor a lender be".replacingOccurrences(of: "[bcdfghjklmnpqrstvwxyz]", with: "A", options: [.regularExpression, .caseInsensitive], range: nil))








print("Change all instances of 'ss' in the following string to be 'FEDEX': 'Mississippi'\n, and change all instances of 'pp' to be 'UPS'")
print("MISSISSIPPI".replacingOccurrences(of: "SS", with: "FEDEX").replacingOccurrences(of: "PP", with: "UPS"))



//print("Write a function public(_ words: [String]) → [String], that strips off the prefix and suffix '__' from an array of Strings, and returns the stripped words as an array of Strings.\nTest it on the following array of Strings: ["__str__", "__ne__", "__eq__", "__le__"])\n")

var words: [String] = ["__str__", "__ne__", "__eq__", "__le__"]

func publicFunc(_ words: [String]) -> [String]{
    var newWords: [String] = []
    for word in words{
        word.replacingOccurrences(of: "__", with: "")
        newWords.append(word)
    }
    print(newWords)
    return newWords
}
publicFunc(words)







print("Using a range, print out all of the squares, and cubes of x from x=[1,10).")
for i in 1 ... (10) {
    print(i,"Square: ",Double(i).squareRoot(), "Cube:" ,i*i*i)
}



print("Write an instance of a variable of type Int that declares the type and its value.")

let instance : Int = 0


print("Create a named tuple: title, author, isbn, that describes a novel, using a typealias similar to this: typealias point = (x: Double, y: Double).  Then, create an instance of a novel, and print out the tuple's elements from the novel")
typealias novel = (title: String, author: String, isbn: Int, desc: String)
let coolbook: novel = ("coolbookies", "coolWriter", 9783161484100, "A cool book")
print(coolbook.title, coolbook.author, coolbook.isbn, coolbook.desc)





print("Write a function that prints out a table of conversions from Kelvin to Fahrenheit, from 0 K to 300 K, in steps of 25 degrees K. Each line should have the Kelvin and Celsius temperatures. Write the program using functions.")
    //You can use conversion functions k2c() and c2f() to simplify the conversion, or just implement it in one step.
func k2f_temp_table(_ start: Int, _ stop: Int, _ step: Int) {    // fill in this code
    func k2c(kelvin: Int) -> Double{
        return (Double(kelvin) - (273.15))
    }
    func c2f(Celius: Double) -> Double{
        return (Double((Celius * 9/5) + 32))
    }
    for i in stop ... (start - step){
    
        
        print("Kelvin: ", i, "Celcius: ", k2c(kelvin: i), "Fahrenheit: ", c2f(Celius: k2c(kelvin: i)) )
    
    }
}
k2f_temp_table(100, 0, 25)

print("Write a function that takes an [Int], and returns an [Int] that are multiples of 2 or 5.")

var numArray: [Int] = [2,4,5,6,10]
func mutiple(num: [Int])-> [Int]{
    var temp: [Int] = []
    for i in 0...num.count-1{
        if num[i] % 2 == 0 || num[i] % 2 == 0{
            temp.append(num[i])
        }
    }
    return temp
}
print(mutiple(num: numArray))




print("Create two Sets of Ints, that have some integers overlapping, and \nCreate a Set that contains all of the items that are NOT in common.")

let s : Set = [1,2,3,4]
let ss : Set = [3,4,5,6]
print(s.intersection(ss))



print("Make an Array of seven Strings, and search for a String in that Array. Write code that will print out the index of that String if found, or that prints out 'nil' if it is not.\n")
let strArr : [String] = ["three", "two", "one", "four", "five", "six", "seven"]

func stringInArrayAtIndex(list: [String], word: String) -> Int?{
    var index = 0
    for i in list{
        if (i == word){
            return index
        }
        index += 1
    }
    return nil
}

var myInt : Int? = stringInArrayAtIndex(list: strArr, word: "one")
print(myInt!)







print("Write a function that divides a list of words into those before a given dividing String, and those equal or after to that String.\n")

func partitionString(_ strings: [String], byDivisor: String) -> (before: [String], eqOAf: [String]){
    var before = [String]()
    var eqOAf = [String]()
    for s in strings{
        if (s < byDivisor){
            before.append(s)
        }
        else {
            eqOAf.append(s)
        }
    }
    return(before, eqOAf)
}
print("let divided = partitionStrings([\"at\", \"be\", \"cat\", \"dog\", \"fox\", \"lima\", \"snake\", \"yak\"], \nbyDivisor: \"goat\")\nprint(divided)\n\n//output\n(before: [\"at\", \"be\", \"cat\", \"dog\", \"fox\"], equalAndAfter: [\"lima\", \"snake\", \"yak\"])\n\n//Hint: You may find the following function helpful\nfunc sortedEvenOddNumbers(_ numbers: [Int]) -> (evens: [Int], odds: [Int]) {\n\tvar evens = [Int]()\n\tvar odds = [Int]()\n\tfor number in numbers {\n\t\tif number % 2 == 0 { evens.append(number);\n\t\t} else { odds.append(number) }\n\t}\n\treturn (evens, odds)\n}")

print("================================================== running function partitionStrings()...")
let divided = partitionString(["at", "be", "cat", "dog", "fox", "lima", "snake", "yak"], byDivisor: "goat")

print(divided)
print("================================================== running function partitionStrings()...\n\n")



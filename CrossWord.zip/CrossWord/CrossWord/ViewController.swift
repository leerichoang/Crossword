import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var buttonAA: CustomButton!
    @IBOutlet var buttonAB: CustomButton!
    @IBOutlet var buttonAC: CustomButton!
    @IBOutlet var buttonAD: CustomButton!
    @IBOutlet var buttonAE: CustomButton!
    @IBOutlet var buttonAF: CustomButton!
    @IBOutlet var buttonAG: CustomButton!
    @IBOutlet var buttonAH: CustomButton!
    @IBOutlet var buttonAI: CustomButton!
    @IBOutlet var buttonAJ: CustomButton!
    @IBOutlet var buttonAK: CustomButton!
    @IBOutlet var buttonAL: CustomButton!
    @IBOutlet var buttonAM: CustomButton!
    @IBOutlet var buttonAN: CustomButton!
    @IBOutlet var buttonAO: CustomButton!
    
    @IBOutlet var buttonBA: CustomButton!
    @IBOutlet var buttonBB: CustomButton!
    @IBOutlet var buttonBC: CustomButton!
    @IBOutlet var buttonBD: CustomButton!
    @IBOutlet var buttonBE: CustomButton!
    @IBOutlet var buttonBF: CustomButton!
    @IBOutlet var buttonBG: CustomButton!
    @IBOutlet var buttonBH: CustomButton!
    @IBOutlet var buttonBI: CustomButton!
    @IBOutlet var buttonBJ: CustomButton!
    @IBOutlet var buttonBK: CustomButton!
    @IBOutlet var buttonBL: CustomButton!
    @IBOutlet var buttonBM: CustomButton!
    @IBOutlet var buttonBN: CustomButton!
    @IBOutlet var buttonBO: CustomButton!
    
    @IBOutlet var buttonCA: CustomButton!
    @IBOutlet var buttonCB: CustomButton!
    @IBOutlet var buttonCC: CustomButton!
    @IBOutlet var buttonCD: CustomButton!
    @IBOutlet var buttonCE: CustomButton!
    @IBOutlet var buttonCF: CustomButton!
    @IBOutlet var buttonCG: CustomButton!
    @IBOutlet var buttonCH: CustomButton!
    @IBOutlet var buttonCI: CustomButton!
    @IBOutlet var buttonCJ: CustomButton!
    @IBOutlet var buttonCK: CustomButton!
    @IBOutlet var buttonCL: CustomButton!
    @IBOutlet var buttonCM: CustomButton!
    @IBOutlet var buttonCN: CustomButton!
    @IBOutlet var buttonCO: CustomButton!
    
    @IBOutlet var buttonDA: CustomButton!
    @IBOutlet var buttonDB: CustomButton!
    @IBOutlet var buttonDC: CustomButton!
    @IBOutlet var buttonDD: CustomButton!
    @IBOutlet var buttonDE: CustomButton!
    @IBOutlet var buttonDF: CustomButton!
    @IBOutlet var buttonDG: CustomButton!
    @IBOutlet var buttonDH: CustomButton!
    @IBOutlet var buttonDI: CustomButton!
    @IBOutlet var buttonDJ: CustomButton!
    @IBOutlet var buttonDK: CustomButton!
    @IBOutlet var buttonDL: CustomButton!
    @IBOutlet var buttonDM: CustomButton!
    @IBOutlet var buttonDN: CustomButton!
    @IBOutlet var buttonDO: CustomButton!
    
    @IBOutlet var buttonEA: CustomButton!
    @IBOutlet var buttonEB: CustomButton!
    @IBOutlet var buttonEC: CustomButton!
    @IBOutlet var buttonED: CustomButton!
    @IBOutlet var buttonEE: CustomButton!
    @IBOutlet var buttonEF: CustomButton!
    @IBOutlet var buttonEG: CustomButton!
    @IBOutlet var buttonEH: CustomButton!
    @IBOutlet var buttonEI: CustomButton!
    @IBOutlet var buttonEJ: CustomButton!
    @IBOutlet var buttonEK: CustomButton!
    @IBOutlet var buttonEL: CustomButton!
    @IBOutlet var buttonEM: CustomButton!
    @IBOutlet var buttonEN: CustomButton!
    @IBOutlet var buttonEO: CustomButton!
    
    @IBOutlet var buttonFA: CustomButton!
    @IBOutlet var buttonFB: CustomButton!
    @IBOutlet var buttonFC: CustomButton!
    @IBOutlet var buttonFD: CustomButton!
    @IBOutlet var buttonFE: CustomButton!
    @IBOutlet var buttonFF: CustomButton!
    @IBOutlet var buttonFG: CustomButton!
    @IBOutlet var buttonFH: CustomButton!
    @IBOutlet var buttonFI: CustomButton!
    @IBOutlet var buttonFJ: CustomButton!
    @IBOutlet var buttonFK: CustomButton!
    @IBOutlet var buttonFL: CustomButton!
    @IBOutlet var buttonFM: CustomButton!
    @IBOutlet var buttonFN: CustomButton!
    @IBOutlet var buttonFO: CustomButton!
    
    @IBOutlet var buttonGA: CustomButton!
    @IBOutlet var buttonGB: CustomButton!
    @IBOutlet var buttonGC: CustomButton!
    @IBOutlet var buttonGD: CustomButton!
    @IBOutlet var buttonGE: CustomButton!
    @IBOutlet var buttonGF: CustomButton!
    @IBOutlet var buttonGG: CustomButton!
    @IBOutlet var buttonGH: CustomButton!
    @IBOutlet var buttonGI: CustomButton!
    @IBOutlet var buttonGJ: CustomButton!
    @IBOutlet var buttonGK: CustomButton!
    @IBOutlet var buttonGL: CustomButton!
    @IBOutlet var buttonGM: CustomButton!
    @IBOutlet var buttonGN: CustomButton!
    @IBOutlet var buttonGO: CustomButton!
    
    @IBOutlet var buttonHA: CustomButton!
    @IBOutlet var buttonHB: CustomButton!
    @IBOutlet var buttonHC: CustomButton!
    @IBOutlet var buttonHD: CustomButton!
    @IBOutlet var buttonHE: CustomButton!
    @IBOutlet var buttonHF: CustomButton!
    @IBOutlet var buttonHG: CustomButton!
    @IBOutlet var buttonHH: CustomButton!
    @IBOutlet var buttonHI: CustomButton!
    @IBOutlet var buttonHJ: CustomButton!
    @IBOutlet var buttonHK: CustomButton!
    @IBOutlet var buttonHL: CustomButton!
    @IBOutlet var buttonHM: CustomButton!
    @IBOutlet var buttonHN: CustomButton!
    @IBOutlet var buttonHO: CustomButton!
    
    @IBOutlet var buttonIA: CustomButton!
    @IBOutlet var buttonIB: CustomButton!
    @IBOutlet var buttonIC: CustomButton!
    @IBOutlet var buttonID: CustomButton!
    @IBOutlet var buttonIE: CustomButton!
    @IBOutlet var buttonIF: CustomButton!
    @IBOutlet var buttonIG: CustomButton!
    @IBOutlet var buttonIH: CustomButton!
    @IBOutlet var buttonII: CustomButton!
    @IBOutlet var buttonIJ: CustomButton!
    @IBOutlet var buttonIK: CustomButton!
    @IBOutlet var buttonIL: CustomButton!
    @IBOutlet var buttonIM: CustomButton!
    @IBOutlet var buttonIN: CustomButton!
    @IBOutlet var buttonIO: CustomButton!
    
    @IBOutlet var buttonJA: CustomButton!
    @IBOutlet var buttonJB: CustomButton!
    @IBOutlet var buttonJC: CustomButton!
    @IBOutlet var buttonJD: CustomButton!
    @IBOutlet var buttonJE: CustomButton!
    @IBOutlet var buttonJF: CustomButton!
    @IBOutlet var buttonJG: CustomButton!
    @IBOutlet var buttonJH: CustomButton!
    @IBOutlet var buttonJI: CustomButton!
    @IBOutlet var buttonJJ: CustomButton!
    @IBOutlet var buttonJK: CustomButton!
    @IBOutlet var buttonJL: CustomButton!
    @IBOutlet var buttonJM: CustomButton!
    @IBOutlet var buttonJN: CustomButton!
    @IBOutlet var buttonJO: CustomButton!
    
    @IBOutlet var buttonKA: CustomButton!
    @IBOutlet var buttonKB: CustomButton!
    @IBOutlet var buttonKC: CustomButton!
    @IBOutlet var buttonKD: CustomButton!
    @IBOutlet var buttonKE: CustomButton!
    @IBOutlet var buttonKF: CustomButton!
    @IBOutlet var buttonKG: CustomButton!
    @IBOutlet var buttonKH: CustomButton!
    @IBOutlet var buttonKI: CustomButton!
    @IBOutlet var buttonKJ: CustomButton!
    @IBOutlet var buttonKK: CustomButton!
    @IBOutlet var buttonKL: CustomButton!
    @IBOutlet var buttonKM: CustomButton!
    @IBOutlet var buttonKN: CustomButton!
    @IBOutlet var buttonKO: CustomButton!
    
    @IBOutlet var buttonLA: CustomButton!
    @IBOutlet var buttonLB: CustomButton!
    @IBOutlet var buttonLC: CustomButton!
    @IBOutlet var buttonLD: CustomButton!
    @IBOutlet var buttonLE: CustomButton!
    @IBOutlet var buttonLF: CustomButton!
    @IBOutlet var buttonLG: CustomButton!
    @IBOutlet var buttonLH: CustomButton!
    @IBOutlet var buttonLI: CustomButton!
    @IBOutlet var buttonLJ: CustomButton!
    @IBOutlet var buttonLK: CustomButton!
    @IBOutlet var buttonLL: CustomButton!
    @IBOutlet var buttonLM: CustomButton!
    @IBOutlet var buttonLN: CustomButton!
    @IBOutlet var buttonLO: CustomButton!
    
    @IBOutlet var buttonMA: CustomButton!
    @IBOutlet var buttonMB: CustomButton!
    @IBOutlet var buttonMC: CustomButton!
    @IBOutlet var buttonMD: CustomButton!
    @IBOutlet var buttonME: CustomButton!
    @IBOutlet var buttonMF: CustomButton!
    @IBOutlet var buttonMG: CustomButton!
    @IBOutlet var buttonMH: CustomButton!
    @IBOutlet var buttonMI: CustomButton!
    @IBOutlet var buttonMJ: CustomButton!
    @IBOutlet var buttonMK: CustomButton!
    @IBOutlet var buttonML: CustomButton!
    @IBOutlet var buttonMM: CustomButton!
    @IBOutlet var buttonMN: CustomButton!
    @IBOutlet var buttonMO: CustomButton!
    
    
    @IBOutlet var buttonNA: CustomButton!
    @IBOutlet var buttonNB: CustomButton!
    @IBOutlet var buttonNC: CustomButton!
    @IBOutlet var buttonND: CustomButton!
    @IBOutlet var buttonNE: CustomButton!
    @IBOutlet var buttonNF: CustomButton!
    @IBOutlet var buttonNG: CustomButton!
    @IBOutlet var buttonNH: CustomButton!
    @IBOutlet var buttonNI: CustomButton!
    @IBOutlet var buttonNJ: CustomButton!
    @IBOutlet var buttonNK: CustomButton!
    @IBOutlet var buttonNL: CustomButton!
    @IBOutlet var buttonNM: CustomButton!
    @IBOutlet var buttonNN: CustomButton!
    @IBOutlet var buttonNO: CustomButton!
    
    @IBOutlet var buttonOA: CustomButton!
    @IBOutlet var buttonOB: CustomButton!
    @IBOutlet var buttonOC: CustomButton!
    @IBOutlet var buttonOD: CustomButton!
    @IBOutlet var buttonOE: CustomButton!
    @IBOutlet var buttonOF: CustomButton!
    @IBOutlet var buttonOG: CustomButton!
    @IBOutlet var buttonOH: CustomButton!
    @IBOutlet var buttonOI: CustomButton!
    @IBOutlet var buttonOJ: CustomButton!
    @IBOutlet var buttonOK: CustomButton!
    @IBOutlet var buttonOL: CustomButton!
    @IBOutlet var buttonOM: CustomButton!
    @IBOutlet var buttonON: CustomButton!
    @IBOutlet var buttonOO: CustomButton!
    
    @IBOutlet var keyQ: CustomButton!
    @IBOutlet var keyW: CustomButton!
    @IBOutlet var keyE: CustomButton!
    @IBOutlet var keyR: CustomButton!
    @IBOutlet var keyT: CustomButton!
    @IBOutlet var keyY: CustomButton!
    @IBOutlet var keyU: CustomButton!
    @IBOutlet var keyI: CustomButton!
    @IBOutlet var keyO: CustomButton!
    @IBOutlet var keyP: CustomButton!
    
    @IBOutlet var keyA: CustomButton!
    @IBOutlet var keyS: CustomButton!
    @IBOutlet var keyD: CustomButton!
    @IBOutlet var keyF: CustomButton!
    @IBOutlet var keyG: CustomButton!
    @IBOutlet var keyJ: CustomButton!
    @IBOutlet var keyH: CustomButton!
    @IBOutlet var keyK: CustomButton!
    @IBOutlet var keyL: CustomButton!
    
    @IBOutlet var keyZ: CustomButton!
    @IBOutlet var keyX: CustomButton!
    @IBOutlet var keyC: CustomButton!
    @IBOutlet var keyV: CustomButton!
    @IBOutlet var keyB: CustomButton!
    @IBOutlet var keyN: CustomButton!
    @IBOutlet var keyM: CustomButton!
    @IBOutlet var keyDel: CustomButton!
    @IBOutlet var keyDir: CustomButton!
    
    @IBOutlet var boxHint: UILabel!
    
    
    var currRow  = 0
    var currCol  = 0
    var free: Bool = false
    var isCorrect: Bool = false
    var dir = 1
    var clue = 0
    var grid   = ["A","H","E","M",".","N","A","N","A",".","C","L","O","V","E","D","I","V","A",".","O","W","E","S",".","L","A","V","A","S","A","M","E","N",".","M","A","N","I","C","U","R","I","S","T","M","A","N","D","R","A","K","E",".","A","B","I","D","E",".",".",".",".","A","I","D","E",".","R","I","M","A",".",".",".","S","P","A","R","E","S",".","M","A","N","A","T","E","E","S","E","O","S","I","N",".","D","O","Z","E","N",".","L","A","T","A","S","S","N",".","S","O","R","E","S",".","D","O","G","E","T","I","E",".","E","T","W","A","S",".","R","E","P","E","L","O","T","T","O","M","A","N","S",".","C","A","M","E","R","A",".",".",".","L","U","M","S",".","S","A","R","A",".",".",".",".","L","A","D","L","E",".","F","U","M","A","N","C","H","U","M","A","N","H","A","N","D","L","E","D",".","D","O","U","R","G","R","O","A","T",".","D","A","D","E",".","E","L","L","A","T","A","N","T","E",".","S","T","E","N",".","D","E","A","L"]
    var gridTag = [1,2,3,4,0,5,6,7,8,0,9,10,11,12,13,14,0,0,0,0,15,0,0,0,0,16,0,0,0,0,17,0,0,0,0,18,0,0,0,19,0,0,0,0,0,20,0,0,0,21,0,0,0,0,22,0,0,0,0,0,0,0,0,23,0,0,0,0,24,0,0,0,0,0,0,25,26,27,0,0,0,0,28,0,0,0,0,29,30,31,32,0,0,0,0,0,33,0,0,0,0,0,34,0,0,35,0,0,0,0,36,0,0,0,0,0,37,0,0,0,38,0,0,0,39,0,0,0,0,0,40,0,0,0,0,41,0,0,42,0,0,0,0,0,43,0,0,0,0,0,0,0,0,44,0,0,0,0,45,0,0,0,0,0,0,0,46,47,0,0,0,0,48,0,0,0,0,49,50,51,52,0,0,0,0,0,53,0,0,0,0,54,0,0,0,55,0,0,0,0,0,56,0,0,0,0,57,0,0,0,58,0,0,0,0,0,59,0,0,0,0,60,0,0,0]
    
    var across = ["1. Attention getter","5. Zola title","9. Garlic unit","14. Met V.I.P.","15. Is obligated","16. Volcanic outputs","17. Hymn word","18. Nail specialist","20. May apple","22. Tolerate","23. Staff man","24. Terza ___","25. Bowling scores","28. Aquatic mammals","32. Red dye","33. Baker's ___","34. Geographical abbr.","35. Org.","36. Tender spots","37. Venetian ruler","38. Draw","39. Something, in Germany","40. Turn back","41. Footstools","43. \"I am a ___\"","44. Chimneys, in Glasgow","45. Teasdale","46. Soup server","48. Fictional villain","52. Pawed","54. Sullen","55. Old English coin","56. Florida county","57. Fitzgerald","58. French relative","59. Machine gun","60. Start a card game"]
    
    var down = ["1. Bede","2. Uganda people","3. Smooth","4. Orange","5. Restless ones","6. On one's toes","7. Hawaiian goose","8. \"___ was saying . . . \"","9. Elk or Rotarian","10. Lasso","11. Roman poet","12. Flower holder","13. Superlative ending","19. Actor Michael and family","21. Nothing, in Paris","24. Destroys","25. Treaty org.","26. Assume","27. Black-ink item","28. S.A. trees","29. Run off","30. Agog","31. Stone slab","33. Football units","36. Flower part","37. Called for","39. Rival","40. ___ avis","42. Passé","43. N.J. city","45. Shoe material","46. Pasternak heroine","47. Soon","48. Stale","49. Porter","50. Oahu dance","51. Russian range","52. Labor's counterpart: Abbr.","53. Dental degree"]
    
    var key = [
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ["A","B","C","D","E", "F", "G", "H" , "I" , "J", "K" ,"L", "M", "N", "O"],
        ]
    var k = 0
    
    @IBAction func changeDir( _ sender: UIButton){
        if dir == 0{
            sender.setTitle("V", for: .normal)
            self.dir = 1
        } else{
            sender.setTitle("H", for: .normal)
            self.dir = 0
        }
    }
    
    
    
    @IBOutlet var stackVertical: UIStackView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let buttons = [
            [buttonAA, buttonBA, buttonCA, buttonDA, buttonEA, buttonFA, buttonGA, buttonHA, buttonIA, buttonJA, buttonKA, buttonLA,buttonMA,buttonNA,buttonOA],
            [buttonAB, buttonBB, buttonCB, buttonDB, buttonEB, buttonFB, buttonGB, buttonHB, buttonIB, buttonJB, buttonKB, buttonLB,buttonMB,buttonNB,buttonOB],
            [buttonAC, buttonBC, buttonCC, buttonDC, buttonEC, buttonFC, buttonGC, buttonHC, buttonIC, buttonJC, buttonKC, buttonLC,buttonMC,buttonNC,buttonOC],
            [buttonAD, buttonBD, buttonCD, buttonDD, buttonED, buttonFD, buttonGD, buttonHD, buttonID, buttonJD, buttonKD, buttonLD,buttonMD,buttonND,buttonOD],
            [buttonAE, buttonBE, buttonCE, buttonDE, buttonEE, buttonFE, buttonGE, buttonHE, buttonIE, buttonJE, buttonKE, buttonLE,buttonME,buttonNE,buttonOE],
            [buttonAF, buttonBF, buttonCF, buttonDF, buttonEF, buttonFF, buttonGF, buttonHF, buttonIF, buttonJF, buttonKF, buttonLF,buttonMF,buttonNF,buttonOF],
            [buttonAG, buttonBG, buttonCG, buttonDG, buttonEG, buttonFG, buttonGG, buttonHG, buttonIG, buttonJG, buttonKG, buttonLG,buttonMG,buttonNG,buttonOG],
            [buttonAH, buttonBH, buttonCH, buttonDH, buttonEH, buttonFH, buttonGH, buttonHH, buttonIH, buttonJH, buttonKH, buttonLH,buttonMH,buttonNH,buttonOH],
            [buttonAI, buttonBI, buttonCI, buttonDI, buttonEI, buttonFI, buttonGI, buttonHI, buttonII, buttonJI, buttonKI, buttonLI,buttonMI,buttonNI,buttonOI],
            [buttonAJ, buttonBJ, buttonCJ, buttonDJ, buttonEJ, buttonFJ, buttonGJ, buttonHJ, buttonIJ, buttonJJ, buttonKJ, buttonLJ,buttonMJ,buttonNJ,buttonOJ],
            [buttonAK, buttonBK, buttonCK, buttonDK, buttonEK, buttonFK, buttonGK, buttonHK, buttonIK, buttonJK, buttonKK, buttonLK,buttonMK,buttonNK,buttonOK],
            [buttonAL, buttonBL, buttonCL, buttonDL, buttonEL, buttonFL, buttonGL, buttonHL, buttonIL, buttonJL, buttonKL, buttonLL,buttonML,buttonNL,buttonOL],
            [buttonAM, buttonBM, buttonCM, buttonDM, buttonEM, buttonFM, buttonGM, buttonHM, buttonIM, buttonJM, buttonKM, buttonLM,buttonMM,buttonNM,buttonOM],
            [buttonAN, buttonBN, buttonCN, buttonDN, buttonEN, buttonFN, buttonGN, buttonHN, buttonIN, buttonJN, buttonKN, buttonLN,buttonMN,buttonNN,buttonON],
            [buttonAO, buttonBO, buttonCO, buttonDO, buttonEO, buttonFO, buttonGO, buttonHO, buttonIO, buttonJO, buttonKO, buttonLO,buttonMO,buttonNO,buttonOO],
            ]
        
        
        
        // assigning each button their value.
        for i in 0...14{
            for j in 0...14{
                self.key[i][j] = grid[k]
                buttons[i][j]?.setTitle(grid[k], for: .normal)
                buttons[i][j]?.tag = gridTag[k]
                self.k += 1
                if buttons[i][j]?.currentTitle == "."{
                    buttons[i][j]?.backgroundColor = UIColor.black
                    buttons[i][j]?.isEnabled = false
                    buttons[i][j]?.setTitle("  ", for: .normal)
                }else if buttons[i][j]?.currentTitle != "."{
                    
                    buttons[i][j]?.setTitle( "  " , for: .normal)
                    
                }
                print(key[i][j])
            }
        } // For loop end
        
        
    }
    
    
    @IBAction func changeButton(_ sender:UIButton){
        let buttons = [
            [buttonAA, buttonBA, buttonCA, buttonDA, buttonEA, buttonFA, buttonGA, buttonHA, buttonIA, buttonJA, buttonKA, buttonLA,buttonMA,buttonNA,buttonOA],
            [buttonAB, buttonBB, buttonCB, buttonDB, buttonEB, buttonFB, buttonGB, buttonHB, buttonIB, buttonJB, buttonKB, buttonLB,buttonMB,buttonNB,buttonOB],
            [buttonAC, buttonBC, buttonCC, buttonDC, buttonEC, buttonFC, buttonGC, buttonHC, buttonIC, buttonJC, buttonKC, buttonLC,buttonMC,buttonNC,buttonOC],
            [buttonAD, buttonBD, buttonCD, buttonDD, buttonED, buttonFD, buttonGD, buttonHD, buttonID, buttonJD, buttonKD, buttonLD,buttonMD,buttonND,buttonOD],
            [buttonAE, buttonBE, buttonCE, buttonDE, buttonEE, buttonFE, buttonGE, buttonHE, buttonIE, buttonJE, buttonKE, buttonLE,buttonME,buttonNE,buttonOE],
            [buttonAF, buttonBF, buttonCF, buttonDF, buttonEF, buttonFF, buttonGF, buttonHF, buttonIF, buttonJF, buttonKF, buttonLF,buttonMF,buttonNF,buttonOF],
            [buttonAG, buttonBG, buttonCG, buttonDG, buttonEG, buttonFG, buttonGG, buttonHG, buttonIG, buttonJG, buttonKG, buttonLG,buttonMG,buttonNG,buttonOG],
            [buttonAH, buttonBH, buttonCH, buttonDH, buttonEH, buttonFH, buttonGH, buttonHH, buttonIH, buttonJH, buttonKH, buttonLH,buttonMH,buttonNH,buttonOH],
            [buttonAI, buttonBI, buttonCI, buttonDI, buttonEI, buttonFI, buttonGI, buttonHI, buttonII, buttonJI, buttonKI, buttonLI,buttonMI,buttonNI,buttonOI],
            [buttonAJ, buttonBJ, buttonCJ, buttonDJ, buttonEJ, buttonFJ, buttonGJ, buttonHJ, buttonIJ, buttonJJ, buttonKJ, buttonLJ,buttonMJ,buttonNJ,buttonOJ],
            [buttonAK, buttonBK, buttonCK, buttonDK, buttonEK, buttonFK, buttonGK, buttonHK, buttonIK, buttonJK, buttonKK, buttonLK,buttonMK,buttonNK,buttonOK],
            [buttonAL, buttonBL, buttonCL, buttonDL, buttonEL, buttonFL, buttonGL, buttonHL, buttonIL, buttonJL, buttonKL, buttonLL,buttonML,buttonNL,buttonOL],
            [buttonAM, buttonBM, buttonCM, buttonDM, buttonEM, buttonFM, buttonGM, buttonHM, buttonIM, buttonJM, buttonKM, buttonLM,buttonMM,buttonNM,buttonOM],
            [buttonAN, buttonBN, buttonCN, buttonDN, buttonEN, buttonFN, buttonGN, buttonHN, buttonIN, buttonJN, buttonKN, buttonLN,buttonMN,buttonNN,buttonON],
            [buttonAO, buttonBO, buttonCO, buttonDO, buttonEO, buttonFO, buttonGO, buttonHO, buttonIO, buttonJO, buttonKO, buttonLO,buttonMO,buttonNO,buttonOO],
            ]
        func checkRight(row: Int, col: Int){
            if col >= 0 && col <= 14{
                if buttons[row][col]?.backgroundColor != UIColor.black{
                    buttons[row][col]?.backgroundColor = UIColor.blue
                    checkRight(row: row, col: col+1)
                    self.dir = 0
                }
            }
        }
        
        func checkLeft(row: Int, col: Int){
            if col >= 0 && col <= 15{
                if  buttons[row][col]?.backgroundColor != UIColor.black{
                    buttons[row][col]?.backgroundColor = UIColor.blue
                    checkLeft(row: row, col: col-1)
                    self.dir = 0
                }
                
            }
        }
        func checkUp(row:Int, col: Int){
            if row >= 0 && row <= 14 && dir != 0{
                if buttons[row][col]?.backgroundColor != UIColor.black{
                    buttons[row][col]?.backgroundColor = UIColor.green
                    checkUp(row: row+1, col: col)
                    self.dir = 1
                }
            }
        }
        
        func checkDown(row:Int, col: Int){
            if row >= 0 && row <= 14 && dir != 0{
                if buttons[row][col]?.backgroundColor != UIColor.black{
                    buttons[row][col]?.backgroundColor = UIColor.green
                    checkDown(row: row-1, col: col)
                    self.dir = 1
                }
            }
        }
        
        func isRight(row:Int, col: Int){
            print ("\(row), \(col), is right")
            if buttons[row][col]?.currentTitle != key[row][col]{
                self.isCorrect  = false
            }
            
            if dir == 0 {
                if col >= 1 && col <= 14 && isCorrect == true{
                    if buttons[row][col-1]?.backgroundColor != UIColor.black{
                        isRight(row: row, col: col-1)
                        
                    }
                }
            }else{
                if row >= 1 && row <= 14 && dir != 0 && isCorrect == true{
                    if buttons[row-1][col]?.backgroundColor != UIColor.black{
                        isRight(row: row-1, col: col)
                        
                    }
                }
            }
        }
        
        func checkisRight(row: Int, col: Int){
            self.isCorrect = true
            isRight(row:row, col: col)
            if isCorrect != false{
                findEnd(row: currRow, col: currCol)
                giveAns(row: currRow, col: currCol)
                
            }
        }
        
        func nextFree(row: Int, col: Int, direction: Int){
            if buttons[row][col]?.backgroundColor == UIColor.black{
                if dir == 1{
                    
                    checkisRight(row: row-1, col: col)
                }else{
                    checkisRight(row: row, col: col-1)
                }
                self.free = false
                return
            }
            if dir != 0 {
                if row >= 14 && direction == 0{
                    self.currRow = 14
                    self.free = true
                    return
                    
                }else if row <= 0  && direction == 1{
                    self.currRow = 0
                    self.free = true
                    return
                    
                }else if direction == 0{
                    if buttons[row][col]?.backgroundColor == UIColor.black || buttons[row][col]?.isEnabled == false{
                        nextFree(row: row+1, col: col, direction: direction)
                    }else{
                        self.free = true
                        self.currRow = row
                        
                    }
                    
                }else if direction == 1{
                    
                    if buttons[row][col]?.backgroundColor == UIColor.black || buttons[row][col]?.isEnabled == false{
                        nextFree(row: row-1, col: col, direction: direction)
                    } else {
                        self.free = true
                        self.currRow = row
                        
                    }
                }
            }else if dir != 1{
                if col >= 14 && direction == 0{
                    self.currCol = 14
                    return
                }else if col <= 0 && direction == 1{
                    self.currCol = 0
                    return
                }else if direction == 0{
                    if buttons[row][col]?.backgroundColor == UIColor.black || buttons[row][col]?.isEnabled == false{
                        nextFree(row: row, col: col+1, direction: direction)
                    }else{
                        self.currCol = col
                        
                    }
                }else if direction == 1{
                    if buttons[row][col]?.backgroundColor == UIColor.black || buttons[row][col]?.isEnabled == false{
                        nextFree(row: row, col: col-1, direction: direction)
                    }else{
                        self.currCol = col
                        
                    }
                }
            }
            
            
        }
        
        func findEnd(row: Int, col: Int){
            self.currRow = row
            self.currCol = col
            
            if dir != 0 {
                if row >= 0 && row <= 13 && dir != 0{
                    if buttons[row][col]?.backgroundColor == UIColor.black{
                        return
                    }
                    
                    if buttons[row+1][col]?.backgroundColor != UIColor.black{
                        buttons[row][col]?.backgroundColor = UIColor.yellow
                        findEnd(row: row+1, col: col)
                        
                    }
                }
            }else {
                if col >= 0 && col <= 13{
                    if buttons[row][col]?.backgroundColor == UIColor.black{
                        return
                    }
                    if buttons[row][col+1]?.backgroundColor != UIColor.black{
                        buttons[row][col]?.backgroundColor = UIColor.yellow
                        findEnd(row: row, col: col+1)
                    }
                    
                }
            }
            
            
            
        }
        func giveAns(row: Int, col: Int){
            buttons[row][col]?.setTitle(key[row][col], for: .normal)
            buttons[row][col]?.backgroundColor = UIColor.white
            buttons[row][col]?.setTitleColor(UIColor.black, for: .normal)
            buttons[row][col]?.isEnabled = false
            print("row: \(row) col: \(col)")
            
            if dir == 0 {
                if col >= 1 && col <= 14{
                    if buttons[row][col-1]?.backgroundColor != UIColor.black{
                        giveAns(row: row, col: col-1)
                        
                    }
                }
            }else{
                if row >= 1 && row <= 14 && dir != 0{
                    if buttons[row-1][col]?.backgroundColor != UIColor.black{
                        giveAns(row: row-1, col: col)
                        
                    }
                }
            }
            
            
            
            
            
        }
        
        
        if sender.currentTitle == " Hint "{
            findEnd(row: currRow, col: currCol)
            
            giveAns(row: currRow, col: currCol)
            
        }else if sender.currentTitle == "del"{
            buttons[currRow][currCol]?.setTitle("  ", for: .normal)
            if dir == 1 && currRow-1 >= 0 && currRow <= 14 && buttons[currRow-1][currCol]?.backgroundColor != UIColor.black{
                nextFree(row: currRow-1, col: currCol, direction: 1)
                buttons[currRow][currCol]?.backgroundColor = UIColor.green
                //self.currRow -= 1
                checkUp(row: currRow, col: currCol)
                checkDown(row: currRow, col: currCol)
                buttons[currRow][currCol]?.backgroundColor = UIColor.red
                
            }
            if dir == 0 && currCol-1 >= 0 && currCol <= 14 && buttons[currRow][currCol-1]?.backgroundColor != UIColor.black{
                nextFree(row: currRow, col: currCol-1, direction: 1)
                
                buttons[currRow][currCol]?.backgroundColor = UIColor.blue
                // self.currCol -= 1
                checkRight(row: currRow, col: currCol)
                checkLeft(row: currRow, col: currCol)
                buttons[currRow][currCol]?.backgroundColor = UIColor.red
                
            }
            
        }else{
            
            buttons[currRow][currCol]?.setTitle(sender.currentTitle, for: .normal)
            
            if dir == 1 && currRow == 14{
                checkisRight(row: currRow, col: currCol)
            }else if dir == 1  && buttons[currRow+1][currCol]?.backgroundColor == UIColor.black {
                checkisRight(row: currRow, col: currCol)
            }else if dir == 0 && currCol == 14{
                checkisRight(row: currRow, col: currCol)
            }else if dir == 0  &&  buttons[currRow][currCol+1]?.backgroundColor == UIColor.black{
                checkisRight(row: currRow, col: currCol)
            }
            
            if dir == 1 && currRow >= 0 && currRow+1 <= 14 && buttons[currRow+1][currCol]?.backgroundColor != UIColor.black{
                
                nextFree(row: currRow+1, col: currCol, direction: 0)
                if free == true{
                    buttons[currRow][currCol]?.backgroundColor = UIColor.green
                    //self.currRow += 1
                    checkUp(row: currRow, col: currCol)
                    checkDown(row: currRow, col: currCol)
                    buttons[currRow][currCol]?.backgroundColor = UIColor.red
                }

                
                
            }
            if dir == 0 && currCol >= 0 && currCol+1 <= 14 && buttons[currRow][currCol+1]?.backgroundColor != UIColor.black{
                nextFree(row: currRow, col: currCol+1, direction: 0)

                if free == true{
                    buttons[currRow][currCol]?.backgroundColor = UIColor.blue
                    //self.currCol += 1
                    checkRight(row: currRow, col: currCol)
                    checkLeft(row: currRow, col: currCol)
                    buttons[currRow][currCol]?.backgroundColor = UIColor.red
                    
                }
                
            }
        }
        
        
        
        
        
    }
    
    
    
    @IBAction func selectSquare(_ sender: UIButton) {
        let buttons = [
            [buttonAA, buttonBA, buttonCA, buttonDA, buttonEA, buttonFA, buttonGA, buttonHA, buttonIA, buttonJA, buttonKA, buttonLA,buttonMA,buttonNA,buttonOA],
            [buttonAB, buttonBB, buttonCB, buttonDB, buttonEB, buttonFB, buttonGB, buttonHB, buttonIB, buttonJB, buttonKB, buttonLB,buttonMB,buttonNB,buttonOB],
            [buttonAC, buttonBC, buttonCC, buttonDC, buttonEC, buttonFC, buttonGC, buttonHC, buttonIC, buttonJC, buttonKC, buttonLC,buttonMC,buttonNC,buttonOC],
            [buttonAD, buttonBD, buttonCD, buttonDD, buttonED, buttonFD, buttonGD, buttonHD, buttonID, buttonJD, buttonKD, buttonLD,buttonMD,buttonND,buttonOD],
            [buttonAE, buttonBE, buttonCE, buttonDE, buttonEE, buttonFE, buttonGE, buttonHE, buttonIE, buttonJE, buttonKE, buttonLE,buttonME,buttonNE,buttonOE],
            [buttonAF, buttonBF, buttonCF, buttonDF, buttonEF, buttonFF, buttonGF, buttonHF, buttonIF, buttonJF, buttonKF, buttonLF,buttonMF,buttonNF,buttonOF],
            [buttonAG, buttonBG, buttonCG, buttonDG, buttonEG, buttonFG, buttonGG, buttonHG, buttonIG, buttonJG, buttonKG, buttonLG,buttonMG,buttonNG,buttonOG],
            [buttonAH, buttonBH, buttonCH, buttonDH, buttonEH, buttonFH, buttonGH, buttonHH, buttonIH, buttonJH, buttonKH, buttonLH,buttonMH,buttonNH,buttonOH],
            [buttonAI, buttonBI, buttonCI, buttonDI, buttonEI, buttonFI, buttonGI, buttonHI, buttonII, buttonJI, buttonKI, buttonLI,buttonMI,buttonNI,buttonOI],
            [buttonAJ, buttonBJ, buttonCJ, buttonDJ, buttonEJ, buttonFJ, buttonGJ, buttonHJ, buttonIJ, buttonJJ, buttonKJ, buttonLJ,buttonMJ,buttonNJ,buttonOJ],
            [buttonAK, buttonBK, buttonCK, buttonDK, buttonEK, buttonFK, buttonGK, buttonHK, buttonIK, buttonJK, buttonKK, buttonLK,buttonMK,buttonNK,buttonOK],
            [buttonAL, buttonBL, buttonCL, buttonDL, buttonEL, buttonFL, buttonGL, buttonHL, buttonIL, buttonJL, buttonKL, buttonLL,buttonML,buttonNL,buttonOL],
            [buttonAM, buttonBM, buttonCM, buttonDM, buttonEM, buttonFM, buttonGM, buttonHM, buttonIM, buttonJM, buttonKM, buttonLM,buttonMM,buttonNM,buttonOM],
            [buttonAN, buttonBN, buttonCN, buttonDN, buttonEN, buttonFN, buttonGN, buttonHN, buttonIN, buttonJN, buttonKN, buttonLN,buttonMN,buttonNN,buttonON],
            [buttonAO, buttonBO, buttonCO, buttonDO, buttonEO, buttonFO, buttonGO, buttonHO, buttonIO, buttonJO, buttonKO, buttonLO,buttonMO,buttonNO,buttonOO],
            ]
        let hint = boxHint
        
        var row: Int = 0
        var col: Int = 0
        
        sender.backgroundColor = UIColor.green
        
        for i in 0...14{
            for j in 0...14{
                
                if buttons[j][i]?.backgroundColor != UIColor.black{
                    
                    buttons[j][i]?.backgroundColor = UIColor.white
                }
                if buttons[j][i]?.isEnabled != false{
                    buttons[j][i]?.setTitle("  ", for: .normal)
                }
            }
        }
        
        func checkRight(row: Int, col: Int){
            if col >= 0 && col <= 14{
                if buttons[row][col]?.backgroundColor != UIColor.black{
                    buttons[row][col]?.backgroundColor = UIColor.blue
                    checkRight(row: row, col: col+1)
                    
                }
            }
        }
        
        func checkLeft(row: Int, col: Int){
            if col >= 0 && col <= 15{
                if  buttons[row][col]?.backgroundColor != UIColor.black{
                    if buttons[row][col]?.currentTitle == "  "{
                        self.currCol = col
                    }
                    if buttons[row][col]?.tag != 0 {
                        self.clue = buttons[row][col]?.tag ?? 0
                    }
                    
                    buttons[row][col]?.backgroundColor = UIColor.blue
                    checkLeft(row: row, col: col-1)
                    
                }
                
            }
        }
        func checkUp(row:Int, col: Int){
            if row >= 0 && row <= 14 {
                if buttons[row][col]?.backgroundColor != UIColor.black{
                    buttons[row][col]?.backgroundColor = UIColor.green
                    checkUp(row: row+1, col: col)
                    
                }
            }
        }
        
        func checkDown(row:Int, col: Int){
            if row >= 0 && row <= 14 {
                if buttons[row][col]?.backgroundColor != UIColor.black{
                    if buttons[row][col]?.currentTitle == "  "{
                        self.currRow = row
                    }
                    if buttons[row][col]?.tag != 0 {
                        self.clue = buttons[row][col]?.tag ?? 0
                    }
                    buttons[row][col]?.backgroundColor = UIColor.green
                    checkDown(row: row-1, col: col)
                    
                }
            }
        }
        
        func updateHint(){
            if dir == 0{
                for i in across{
                    if i.contains( "\(clue)." ){
                        hint?.text = i
                        break
                    }
                }
            }else if dir == 1{
                for i in down{
                    
                    if i.contains( "\(clue)." ){
                        hint?.text = i
                        break
                    }
                }
                
            }
        }
        
        for i in 0...14{
            for j in 0...14{
                if sender == buttons[j][i]{
                    row = j
                    col = i
                    currCol = i
                    currRow = j
                    if buttons[j][i]?.tag != 0{
                        self.clue = buttons[j][i]?.tag ?? 0
                    }
                    
                    
                    
                    if self.dir == 0{
                        buttons[row][col]?.backgroundColor = UIColor.blue
                        checkLeft(row: row, col: col-1)
                        checkRight(row: row, col: col+1)
                    }else{
                        buttons[row][col]?.backgroundColor = UIColor.green
                        checkDown(row: row-1, col: col)
                        checkUp(row: row+1, col: col)
                    }
                    
                    buttons[currRow][currCol]?.backgroundColor = UIColor.red
                    updateHint()
                    
                }
            }
        }
        
        
        
    }
    
    
    
    
}

